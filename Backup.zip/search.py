if request.method == 'POST':
    if request.form['carType']:
        myid = request.form['carType']        
        return render_template('menu.html', car_id = myid)
    if request.form['model']:
        name = request.form['model']
        myname = session.query(CarType).filter_by(name = name).one()
        return render_template('menu.html', car_id = myname.car_id)
        
    
